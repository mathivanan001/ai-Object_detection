# live_detection.py
import torch
import cv2

# Load YOLOv5 model directly from GitHub
model = torch.hub.load('ultralytics/yolov5', 'yolov5s')  # Removed `source='local'` to load from GitHub

def live_object_detection():
    # Initialize webcam
    cap = cv2.VideoCapture(0)  # 0 is usually the default for the built-in webcam

    # Check if the webcam opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    print("Starting live object detection. Press 'q' to quit.")

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to capture image.")
            break

        # Run object detection on the frame
        results = model(frame)
        detections = results.pandas().xyxy[0]  # Get bounding boxes

        # Draw bounding boxes and labels on the frame
        for _, row in detections.iterrows():
            xmin, ymin, xmax, ymax = int(row['xmin']), int(row['ymin']), int(row['xmax']), int(row['ymax'])
            label = f"{row['name']} {row['confidence']:.2f}"

            # Draw bounding box and label
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
            cv2.putText(frame, label, (xmin, ymin - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Display the resulting frame
        cv2.imshow('YOLOv5 Live Object Detection', frame)

        # Exit on pressing 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close windows
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    live_object_detection()
